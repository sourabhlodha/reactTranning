import { actionTypes as types } from '../constants';

const timeline = (state = {}, action) => {
  switch (action.type) {
  case types.SHOW_TIMELINE:
    return ({timeline: true, ehr: false, insurance: false});
  case types.HIDE_TIMELINE:
    return ({timeline: false, ehr: false, insurance: false });
  case types.SHOW_EHR: 
    return ({timeline: false, ehr: true});
  case types.SHOW_INSURANCE: 
    return ({timeline: false, ehr: false, insurance: true});
  default:
    return state;
  }
};

export default timeline;
