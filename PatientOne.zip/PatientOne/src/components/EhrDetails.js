import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';

const EhrDetails = ({user}) => {
  console.log(user);
  let ehrRows;
  if (user.ehr) {
    ehrRows = _.map(user.ehr, (item, i) => {
      return (
        <tr key={i}>
              <td>{item.problem}</td>
              <td>{item.medications}</td>
              <td>{item.servicesDue}</td>
              <td>{item.provider}</td>
              <td>{item.location}</td>
              <td>{item.reason}</td>
            </tr>
      );
    });
  }
  return (
    <div className="mypost-list insuranceDetails">
      <h2>Patient EHR Information</h2>
      <div>
        <table className="table table-bordered">
          <thead>
            <tr>
              <th>Problems</th>
              <th>Medications</th>
              <th>Services Due</th>
              <th>Provider</th>
              <th>Location of Care</th>
              <th>Reason for Visit</th>
            </tr>
          </thead>
          <tbody>
             {ehrRows}
          </tbody>
        </table>
      </div>
    </div>
  );
};

EhrDetails.propTypes = {
  user: PropTypes.object,
};

export default EhrDetails;
