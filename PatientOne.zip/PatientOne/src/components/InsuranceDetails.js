import React from 'react';

const InsuranceDetails = () => {
  return (
    <div className="mypost-list insuranceDetails">
      <h2>Patient Insurance Information</h2>
      <div>
        <table className="table table-bordered">
          <tr>
            <th>Primary Insurance Co:</th>
            <td>Aetna  Group</td>
            <th>Policy No:</th>
            <td>356M59557</td>
            <th>Group No:</th>
            <td>7654213</td>
          </tr>
           <tr>
            <th colSpan="3">Primary Insurance Phone Number:</th>
            <td colSpan="3">202-555-0161</td>
          </tr>
          <tr>
            <th>Subscriber’s Name :</th>
            <td colSpan="2">Martin Haydon</td>
            <th>DOB:</th>
            <td colSpan="2">July 14, 1988</td>
          </tr>
          <tr>
            <th colSpan="3">Subscriber’s Relationship to Patient:</th>
            <td colSpan="3">Husband</td>
          </tr>
          <tr>
            <th>Secondary Insurance Co:</th>
            <td>HCSC</td>
            <th>Policy No:</th>
            <td>45M65787</td>
            <th>Group:</th>
            <td>765597</td>
          </tr>
          <tr>
            <th colSpan="3">Secondary Insurance Phone Number:</th>
            <td colSpan="3">202-555-0161</td>
          </tr>
          <tr>
            <th>Subscriber’s Name :</th>
            <td colSpan="2">John Marshall</td>
            <th>DOB:</th>
            <td colSpan="2">August 28, 1960 </td>
          </tr>
          <tr>
            <th colSpan="3">Subscriber’s Relationship to Patient:</th>
            <td colSpan="3">Brother</td>
          </tr>
        </table>
      </div>
      <h2>Patient Eligibility and Benefits Information</h2>
      <div>
        <table className="table table-bordered">
          <tr>
            <th>Effective Date of Coverage:</th>
            <td>Augst 20, 2018</td>
            <th>Coverage Terminated?:</th>
            <td>No</td>
            <th>Date:</th>
            <td>July, 18, 2017</td>
          </tr>
           <tr>
            <th colSpan="2">In-Network Benefits:<br/><small>(co-payment)</small></th>
            <td colSpan="4" className="text-right">$500</td>
          </tr>
           <tr>
            <th colSpan="2">Deductible</th>
            <td colSpan="4" className="text-right">$50</td>
          </tr>
           <tr>
            <th colSpan="2">Co-insurance Other</th>
            <td colSpan="4"  className="text-right">$200</td>
          </tr>
           <tr>
            <th colSpan="2">Out-of-Pocket Expense</th>
            <td colSpan="4"  className="text-right">$50</td>
          </tr>
           <tr>
            <th colSpan="2">Has Deductible Been Met?</th>
            <td colSpan="4">Yes</td>
          </tr>
          <tr>
            <th>Benefits for Treatment?</th>
            <td>Yes</td>
            <th>Is a Referral Necessary?</th>
            <td>No</td>
            <th>Is Prior‐Authorization Required?</th>
            <td>No</td>
          </tr>
          <tr>
             <th colSpan="2">Out‐of‐Network Benefits?</th>
            <td>Yes</td>
             <th colSpan="2">No Out‐of‐Network Financial Responsibilities?</th>
            <td>No</td>
          </tr>
          <tr>
            <th colSpan="2">Comments:</th>
            <td colSpan="4">A "healthy" young man suffered a heart attack and died after undergoing surgery to make his penis bigger, it has emerged.</td>
          </tr>
        </table>
      </div>

      <h2>Insurer Information</h2>
      <div>
        <table className="table table-bordered">
          <tr>
            <th>Call Date:</th>
            <td>Augst 20, 2018</td>
            <th>Time of Call:</th>
            <td>01:20 PM</td>
          </tr>
           <tr>
            <th>Name of Insurance Rep:</th>
            <td>Amrica Insurance Company</td>
            <th>Phone No / Ext:</th>
            <td>202-555-0111</td>
          </tr>
           <tr>
            <th>Prior‐Authorization Phone No:</th>
            <td>202-545-3561</td>
            <th>Fax No:</th>
            <td>041 444-5555</td>
          </tr>
          <tr>
            <th colSpan="2">Prior-Authorization Contact Name:</th>
            <td colSpan="2">John Marshall</td>
          </tr>
          <tr>
            <th colSpan="2">Prior-Authorization Approval No:</th>
            <td colSpan="2">3452 6548 1234 0500</td>
          </tr>
            <tr>
            <th>Referral Phone No:</th>
            <td>202-545-3561</td>
            <th>Fax No:</th>
            <td>041 444-5555</td>
          </tr>
           <tr>
            <th>Referral Contact Name Notes:</th>
            <td>Julie Mrshall</td>
            <th>Notes:</th>
            <td>NA</td>
          </tr>
        </table>
      </div>
    </div>
  );
};

export default InsuranceDetails;
