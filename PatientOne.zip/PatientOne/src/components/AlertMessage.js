import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';

import { closeAlert } from '../actions';

const AlertMessage = ({ user, closeAlert }) => {
  console.log(user);
  if (user.webcamError.error) {
    return (
      <div className="alert-message">
        {user.webcamError.error}
        <button className="close-alert-message" onClick={closeAlert}>
          <i className="fa fa-close"></i>
        </button>
      </div>
    );
  }
  return null;
};

AlertMessage.propTypes = {
  user: PropTypes.shape({}).isRequired,
  closeAlert: PropTypes.func,
};
const mapStateToProps = state => ({
  user: state.user,
});
export default connect(mapStateToProps, { closeAlert })(AlertMessage);
