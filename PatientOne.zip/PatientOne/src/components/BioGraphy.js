import React from 'react';

const BioGraphy = () => {
  return (
    <div className="mypost-list">
      <h2> HPI: </h2>
      <div>
      Patient reported to OPD complaining of pain to the right shoulder after falling today when she tripped on some sidewalk. 
      Took half of a Vicodin prior to arrival which patientt states has only provided minimal relief. No LOC with fall. No neck pain.
      </div>
      <h2>
      Allergies:  </h2>
      <div>
      No known allergies
      </div>
      <h2>
      Immunization: </h2>
      <div> 
      No immunization on file
      </div>
      <h2>
      Review of Systems Constitutional: </h2>
      <div> 
      Negative for fever and chills.
      </div>
      <h2>
      HENT:  </h2>
      <div>
      Negative.
      </div>
      <h2>
      Respiratory: </h2>
      <div>
      Negative.
      </div>
      <h2>
      Cardiovascular: </h2>
      <div> 
      Negative. 
      </div>
      <h2>
      Gastrointestinal: </h2>
      <div> 
      Negative.
      </div>
      <h2>
      Genitourinary: </h2>
      <div> 
      Negative.
      </div>
      <h2>
      Musculoskeletal: </h2>
      <div>
      Positive for myalgias and falls.
      </div>
      <h2>
      Skin: </h2>
      <div>
      Negative.
      </div>
      <h2>
      Neurological: </h2>
      <div> 
      Negative for dizziness, tingling, sensory change, speech change, focal weakness and
      loss of consciousness.
      </div>
      <h2>
      Endo/Heme/Allergies: </h2>
      <div>
      Negative
      </div>
      <h2>
      Vital: </h2>
      <div>
      <table className="table table-bordered">
        <tr>
          <th width="20%">
            BP
           </th>
          <td>
            <strong>(!)</strong> 154/100
            <br/>mmHg 
            <br/><small>-AD at 06/17/2017 1952</small>
          </td>
        </tr>
        <tr>
         <th>
            Pluse
           </th>
          <td>
            85
            <br/><small>-AD at 06/17/2017 1952</small>
          </td>
        </tr>
        <tr>
          <th>
            Resp
           </th>
          <td>
          16
          <br/><small>-AD at 06/17/2017 1952</small>
          </td>
        </tr>
        <tr>
          <th>
            Temp
           </th>
          <td>
            98.4 °F (36.0 °C)
            <br/><small>-AD at 06/17/2017 1952</small>
          </td>
        </tr>
        <tr>
          <th>
            Temp src
           </th>
          <td>
            Oral
            <br/><small>-AD at 06/17/2017 1952</small>
          </td>
        </tr>
        <tr>
          <th>
            SpO2
           </th>
          <td>
            98%
            <br/><small>-AD at 06/17/2017 1952</small>
          </td>
        </tr>
      </table>
      </div>
       <h2>
      Pain: </h2>
      <div>
      <table className="table table-bordered">
        <tr>
          <th width="20%">
            Pain Scale
          </th>
          <td>
            Numeric
          </td>
        </tr>
        <tr>
          <th>
            Pain Rating
          </th>
          <td>
            10
            <br/><small>-AD at 06/17/2017 1952</small>
          </td>
        </tr>
        <tr>
          <th>
            Pain Goal
          </th>
          <td>
            <small>-AD at 06/17/2017 1952</small>
          </td>
        </tr>
        <tr>
          <th>
            Location
          </th>
          <td>
            L arm
            <br/><small>-AD at 06/17/2017 1952</small>
          </td>
        </tr>
        <tr>
         <th>
            4.9.10<br/>
            Radiates
           </th>
          <td>
            generalized pain, <br/>
            pt non-specific
            <br/><small>-AD at 06/17/2017 1952</small>
          </td>
        </tr>
      </table>
      </div>      
    </div>
  );
};

export default BioGraphy;
