import { actionTypes as types } from '../constants';
import Web3 from 'web3';
import CryptoJS from 'crypto-js';

import { get } from '../helpers';
import _ from 'lodash';

let count = 0;
let newCount = 0; 
export const getPatientList = () => dispatch => {
  console.log('getpatientList');
  const web3 = new Web3(
    new Web3.providers.HttpProvider(
      'http://blockrnyg.westindia.cloudapp.azure.com:8545',
    ),
  );

  const account = web3.eth.getAccounts((err, accs) => accs[0]);
  web3.eth.defaultAccount = account;

  const source =
    'pragma solidity ^0.4.6;contract PatientSafe{struct PatientDetails{string patientName;uint patientId;uint previousPatientId;uint Timestamp;string age;string treatment;}mapping(uint => PatientDetails) Trail;uint8 TrailCount=0;function AddNewPatient(uint patientId, string patientName, string age, string treatment){PatientDetails memory newPatient;newPatient.patientName = patientName;newPatient.patientId = patientId;newPatient.age = age;newPatient.treatment = treatment;newPatient.Timestamp = now;if(TrailCount!=0){newPatient.previousPatientId = Trail[TrailCount].patientId;}Trail[TrailCount] = newPatient;TrailCount++;}function GetTrailCount() returns(uint8){return TrailCount;}function GetPatient(uint8 TrailNo) returns(string,uint,uint,uint,string,string){ return (Trail[TrailNo].patientName, Trail[TrailNo].patientId,Trail[TrailNo].previousPatientId,Trail[TrailNo].Timestamp ,Trail[TrailNo].age, Trail[TrailNo].treatment); }}';

  web3.eth.compile.solidity(source, (error, safeCompiled) => {
    const abi = safeCompiled['<stdin>:PatientSafe'].info.abiDefinition;
    const contract = web3.eth.contract(abi);

    const patientContracts = [
      '0x5bfe2e34ce2fd504dba65ecf10320391ad99cfe9',
      '0xa9bea074764af8db5c92a00e5e27ef3693c6d7db',
      '0x83f2bbb153147b1777320828fa102ba7ae647f2f',
      '0x95715c0c628b17d8f5ec70b53a897a25f280ae0a',
      '0x9ea7775563efc406ed99191599572ac7d735b91a',
      '0x3e9ba5c1f563b62877239ed8719a4e48296ba326',
      '0x49fe87cae187580090509fb51df2533ea6fffd83',
      '0x9d6c9caf661685985905fd041649121a09fcebfa',
      '0xca6aa09c7a263a50a8254d09254b209ffd2a8832',
    ];
    if (count < 9) {
      _.map(patientContracts, contractId => {
        count ++;
        const deployedSafe = contract.at(contractId);

        deployedSafe.GetTrailCount.call((error, trailCount) =>
          deployedSafe.GetPatient.call(trailCount - 1, (err, returnValues) => {
            
            var encryptedPatientName = returnValues[0];
            var encryptedAge = returnValues[4];
            var encryptedTreatment= returnValues[5];
            const passPhrase = '123';
            
            var name = CryptoJS.AES.decrypt(encryptedPatientName, passPhrase).toString(CryptoJS.enc.Utf8);
            var diagnosis = CryptoJS.AES.decrypt(encryptedTreatment, passPhrase).toString(CryptoJS.enc.Utf8);
            var age = CryptoJS.AES.decrypt(encryptedAge, passPhrase).toString(CryptoJS.enc.Utf8);

            const data = {
              name,
              diagnosis,
              age,
            };
            dispatch({ type: types.GET_PATIEN_LIST, data });
          }),
        );
      });
    }
    
   
  });
};

export const getPatient = patientName => dispatch => {
  console.log('patientName');
  console.log(patientName);
  const web3 = new Web3(
    new Web3.providers.HttpProvider(
      'http://blockrnyg.westindia.cloudapp.azure.com:8545',
    ),
  );

  const account = web3.eth.getAccounts((err, accs) => accs[0]);
  web3.eth.defaultAccount = account;

  const source =
    'pragma solidity ^0.4.6;contract PatientSafe{struct PatientDetails{string patientName;uint patientId;uint previousPatientId;uint Timestamp;string age;string treatment;}mapping(uint => PatientDetails) Trail;uint8 TrailCount=0;function AddNewPatient(uint patientId, string patientName, string age, string treatment){PatientDetails memory newPatient;newPatient.patientName = patientName;newPatient.patientId = patientId;newPatient.age = age;newPatient.treatment = treatment;newPatient.Timestamp = now;if(TrailCount!=0){newPatient.previousPatientId = Trail[TrailCount].patientId;}Trail[TrailCount] = newPatient;TrailCount++;}function GetTrailCount() returns(uint8){return TrailCount;}function GetPatient(uint8 TrailNo) returns(string,uint,uint,uint,string,string){ return (Trail[TrailNo].patientName, Trail[TrailNo].patientId,Trail[TrailNo].previousPatientId,Trail[TrailNo].Timestamp ,Trail[TrailNo].age, Trail[TrailNo].treatment); }}';

  web3.eth.compile.solidity(source, (error, safeCompiled) => {
    const abi = safeCompiled['<stdin>:PatientSafe'].info.abiDefinition;
    const contract = web3.eth.contract(abi);
  
    const deployedSafe = contract.at('0x5bfe2e34ce2fd504dba65ecf10320391ad99cfe9');

    deployedSafe.GetTrailCount.call((error, trailCount) =>
      deployedSafe.GetPatient.call(trailCount - 1, (err, returnValues) => {
        
        var encryptedPatientName = returnValues[0];
        // var encryptedAge = returnValues[4];
        // var encryptedTreatment= returnValues[5];
        const passPhrase = '123';
        
        var name = CryptoJS.AES.decrypt(encryptedPatientName, passPhrase).toString(CryptoJS.enc.Utf8);
        // var diagnosis = CryptoJS.AES.decrypt(encryptedTreatment, passPhrase).toString(CryptoJS.enc.Utf8);
        // var age = CryptoJS.AES.decrypt(encryptedAge, passPhrase).toString(CryptoJS.enc.Utf8);

        const data = {
          name,
          bloodGroup: 'B+',
          patientList: patientList,
        };
        dispatch({ type: types.GET_PATIENT, data });
      }),
    );
     
    
   
  });
};

export const getPhiDetail = patientName => dispatch => {
  console.log(patientName);
  const web3 = new Web3(
    new Web3.providers.HttpProvider(
      'http://blockrnyg.westindia.cloudapp.azure.com:8545',
    ),
  );

  const account = web3.eth.getAccounts((err, accs) => accs[0]);
  web3.eth.defaultAccount = account;

  const source =
    'pragma solidity ^0.4.6;contract PHISafe{struct PHIDetails{uint patientId;uint previousPatientId;string billing;string drug_alcohol;string hivTest;string geneticResult;string bloodTest;}mapping(uint => PHIDetails) Trail;uint8 TrailCount=0;function AddNewPatientPHI(uint patientId, string billing, string drug_alcohol, string hivTest,string geneticResult,string bloodTest){PHIDetails memory newPatient;newPatient.patientId = patientId;newPatient.billing = billing;newPatient.drug_alcohol = drug_alcohol;newPatient.hivTest = hivTest;newPatient.geneticResult = geneticResult;newPatient.bloodTest = bloodTest;if(TrailCount!=0){newPatient.previousPatientId = Trail[TrailCount].patientId;}Trail[TrailCount] = newPatient;TrailCount++;}function GetTrailCountPHI() returns(uint8){return TrailCount;}function GetPatientPHI(uint8 TrailNo) returns(uint,uint,string,string,string,string,string){return (Trail[TrailNo].patientId,Trail[TrailNo].previousPatientId,Trail[TrailNo].billing,Trail[TrailNo].drug_alcohol,Trail[TrailNo].hivTest,Trail[TrailNo].geneticResult,Trail[TrailNo].bloodTest);}}';

  web3.eth.compile.solidity(source, (error, safeCompiled) => {
    const abi = safeCompiled['<stdin>:PHISafe'].info.abiDefinition;
    const contract = web3.eth.contract(abi);

    let contractId = '0x1645d9ae46dd4dc352ad9fdbe800d42b69d0037d';

    const deployedSafe = contract.at(contractId);

    deployedSafe.GetTrailCountPHI.call((error, trailCount) =>
      deployedSafe.GetPatientPHI.call(trailCount - 1, (err, returnValues) => {
        const blood = CryptoJS.AES
          .decrypt(returnValues[2], '123')
          .toString(CryptoJS.enc.Utf8);
        const biling = CryptoJS.AES
          .decrypt(returnValues[3], '123')
          .toString(CryptoJS.enc.Utf8);
        const drug = CryptoJS.AES
          .decrypt(returnValues[4], '123')
          .toString(CryptoJS.enc.Utf8);
        const hiv = CryptoJS.AES
          .decrypt(returnValues[5], '123')
          .toString(CryptoJS.enc.Utf8);
        const genetic = CryptoJS.AES
          .decrypt(returnValues[6], '123')
          .toString(CryptoJS.enc.Utf8);

        const data = { blood, biling, drug, hiv, genetic };
        dispatch({ type: types.GET_PHI, data });
      }),
    );
  });
};


export const getEhrDetail = (allContracts) => dispatch => {
  // console.log(patientName);
  const web3 = new Web3(
    new Web3.providers.HttpProvider(
      'http://blockrnyg.westindia.cloudapp.azure.com:8545',
    ),
  );

  const account = web3.eth.getAccounts((err, accs) => accs[0]);
  web3.eth.defaultAccount = account;

  const source =
    'pragma solidity ^0.4.6;contract OtherDetails{struct PHIDetails{uint patientId;uint previousPatientId;string parentPatientContractId; string billing;string drug_alcohol;string hivTest;string geneticResult;string bloodTest;}mapping(uint => PHIDetails) Trail;uint8 TrailCount=0;function AddNewPatientPHI(uint patientId, string parentPatientContractId,string billing, string drug_alcohol, string hivTest,string geneticResult,string bloodTest){PHIDetails memory newPatient;newPatient.patientId = patientId;newPatient.parentPatientContractId = parentPatientContractId;newPatient.billing = billing;newPatient.drug_alcohol = drug_alcohol;newPatient.hivTest = hivTest;newPatient.geneticResult = geneticResult;newPatient.bloodTest = bloodTest;if(TrailCount!=0){    newPatient.previousPatientId = Trail[TrailCount].patientId;}Trail[TrailCount] = newPatient;TrailCount++;}function GetTrailCountPHI() returns(uint8){return TrailCount;}function GetPatientPHI(uint8 TrailNo) returns(uint,string,string,string,string,string,string){   return (Trail[TrailNo].patientId,Trail[TrailNo].parentPatientContractId,Trail[TrailNo].billing,Trail[TrailNo].drug_alcohol,Trail[TrailNo].hivTest,Trail[TrailNo].geneticResult,Trail[TrailNo].bloodTest); }}';

  web3.eth.compile.solidity(source, (error, safeCompiled) => {
    const abi = safeCompiled['<stdin>:OtherDetails'].info.abiDefinition;
    const contract = web3.eth.contract(abi);

    // let contractId = '0x250f04e99aef369bf951f96b84b4835a29ce81c1';
    // let contracts = ['0x250f04e99aef369bf951f96b84b4835a29ce81c1'];
    
    if (newCount < allContracts.length - 1) {
      _.map(allContracts, item => {
        const deployedSafe = contract.at(item.Contract);
        deployedSafe.GetTrailCountPHI.call((error, trailCount) =>
          deployedSafe.GetPatientPHI.call(trailCount - 1, (err, returnValues) => {

            var encryptedProblem = returnValues[1];
            var encryptedMedication = returnValues[2];
            var encryptedService = returnValues[3];
            var encryptedProvider = returnValues[4];
            var encryptedLocation = returnValues[5];
            var Reason = returnValues[6];
            var passPhrase = '123';
          
            var problem = CryptoJS.AES.decrypt(encryptedProblem, passPhrase).toString(CryptoJS.enc.Utf8);
            var medications = CryptoJS.AES.decrypt(encryptedMedication, passPhrase).toString(CryptoJS.enc.Utf8);
            var servicesDue = CryptoJS.AES.decrypt(encryptedService, passPhrase).toString(CryptoJS.enc.Utf8);
            var provider = CryptoJS.AES.decrypt(encryptedProvider, passPhrase).toString(CryptoJS.enc.Utf8);
            var location = CryptoJS.AES.decrypt(encryptedLocation, passPhrase).toString(CryptoJS.enc.Utf8);
            var reason = CryptoJS.AES.decrypt(Reason, passPhrase).toString(CryptoJS.enc.Utf8);

            const data = { problem, medications, servicesDue, provider, location, reason };
            dispatch({ type: types.GET_EHR, data });
          }),
        );
      });
      
    }
    newCount ++;
  });
};

export const showPatientModal = () => dispatch => {
  console.log('showModal');
  dispatch({ type: types.SHOW_PATIENT_MODAL });
};
export const hidePatientModal = () => dispatch => {
  dispatch({ type: types.HIDE_PATIENT_MODAL });
};

export const hospitalChatBot = () => dispatch => {
  dispatch({ type: types.IS_HOSPITAL });
};
export const hospitalChatBotClose = () => dispatch => {
  dispatch({ type: types.IS_HOSPITAL_CLOSE });
};

export const getAllEhrContracts = () => dispatch => {
  dispatch({ type: types.EHR_CONTRACT_REQUEST });
  console.log('getAllEhrContracts');
  get({
    url: 'https://hackthonfunction.azurewebsites.net/api/ContractGet?code=/nxS9xQaNUYqcaNmPKQ5jPZlb0iyKygkBvJoq/Xhj7K1Yj96NIwl8w==',
    success: types.EHR_CONTRACT_SUCCESS,
    failure: types.EHR_CONTRACT_FALIURE,
    dispatch,
  });
};



const patientList = [
  {
    name: 'Joe, Burns',
    city: 'ICU1, City',
    case: 'Arthritis Osteoarthritis',
    address: '89Y F LOS 4D',
    gender: 'F',
  },
  {
    name: 'Samy Haydon',
    city: '507, City',
    case: 'Fall, Contusion Right Shoulder',
    address: '75Y F LOS 1D',
    gender: 'F',
  },
  {
    name: 'Blazer, Roy',
    city: '401, City',
    case: 'Foot pain',
    address: '85Y M LOS 4D',
    gender: 'M',
  },
  {
    name: 'Bonnet, Lola',
    city: '209, City',
    case: 'Fibromyalgia',
    address: '15Y F LOS 4D',
    gender: 'F',
  },
  {
    name: 'Brooks,, Angela',
    city: 'ER, City',
    case: 'Low Back Pain',
    address: '19Y F LOS 7.5H',
    gender: 'F',
  },
  {
    name: 'Chang, Eric',
    city: 'Cling, City',
    case: 'Kyphosis',
    address: '50Y M 01/14/17',
    gender: 'M',
  },
  {
    name: 'Collins, John',
    city: 'Cling, City',
    case: 'Scoliosis',
    address: '54Y M 01/12/17',
    gender: 'M',
  },
  {
    name: 'Darr, Molly',
    city: '501, City',
    case: 'Kyphosis',
    address: '75Y F LOS 4D',
    gender: 'F',
  },
  {
    name: 'Greene, Christinia',
    city: 'Cling, City',
    case: 'Shoulder Pain ',
    address: '75Y F 1/14/17',
    gender: 'F',
  },
];
