const API = 'https://reqres.in/api';

export const LOGIN = `${API}/login`;
