import { actionTypes as types } from '../constants';
const initialState = {
  id: 1,
  token:'123',
};

const page = (state = initialState, action) => {
  switch (action.type) {
  case types.PAGE_ID:
    return {...state, id: action.data};
  default:
    return state;
  }
};

export default page;
