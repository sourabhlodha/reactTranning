import { actionTypes as types } from '../constants';
// import { actionTypes as types, urls } from '../constants';
// import { post } from '../helpers';


export const login = () => dispatch => {
  dispatch({ type: types.LOGIN_SUCCESS, data: {'token': 'token'} });
};

export const logout = () => dispatch => {
  dispatch({ type: types.LOGOUT_REQUEST });
};


export const switchPage = (id ) => dispatch => {
  dispatch({ type: types.PAGE_ID, data: id });
};

