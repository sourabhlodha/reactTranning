import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';

import LogoWhite from '../../assets/images/logo.png';
import FedexAds from '../../assets/images/fedex_ads.png';
import { logout, switchPage } from '../../actions';

const Header = ({ user, logout, page, switchPage }) => {
  if (user.token) {
    return (
      <nav className="col-sm-3 col-md-3 sidebar d-flex flex-column">
        <div className="mb-auto">
          <div className="flogo">
            <img src={LogoWhite} width="90" />
          </div>
          <ul  className="nav nav-pills flex-column">
            <li className="nav-item">
              <button className={`nav-link ${page.id === 1 ? 'active' : 'as'}`} onClick={() => switchPage(1)}>Shipment  Onboarding</button>
            </li>
            <li className="nav-item">
              <button className={`nav-link ${page.id === 2 ? 'active' : 'as'}`}  onClick={() => switchPage(2)}>Shipment Dashboard</button>
            </li>
          </ul>
        </div>
        <div className="ads mb-2">
          <img src={FedexAds} />
        </div>
        <div className="logout">
          <button className="btn btn-link" onClick={logout}>Logout</button>
        </div>
      </nav>
    );
  }
  
  return (
    <header className="navbar navbar-expand flex-md-row bd-navbar">
      <a className="navbar-brand mr-0 mr-md-2" href="/" aria-label="Fedex">
        <img src={LogoWhite} width="90" /> 
      </a>
    </header>
  );
};

Header.propTypes = {
  user: PropTypes.shape({}).isRequired,
  page: PropTypes.shape({}).isRequired,
  logout: PropTypes.func,
  switchPage: PropTypes.func,
};

const mapStateToProps = state => ({ user: state.user, page: state.page });
export default connect(mapStateToProps, { logout, switchPage })(Header);
