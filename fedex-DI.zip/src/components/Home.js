import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Redirect } from 'react-router-dom';

import Main from './Main';

const Home = ({ user, page }) =>
  user.token ? (
    <Main page={page}/>
  ) : (
    <Redirect to="/login" />
  );

Home.propTypes = {
  user: PropTypes.shape({}).isRequired,
  page: PropTypes.shape({}).isRequired,
};

export default connect(state => ({ user: state.user, page: state.page }))(Home);
