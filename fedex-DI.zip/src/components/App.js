import React from 'react';
import PropTypes from 'prop-types';
import { connect } from 'react-redux';
import { Route, Redirect, withRouter, Switch } from 'react-router-dom';
import Async from 'react-code-splitting';

import Login from './Auth/Login';
import Header from './Header';
import Main from './Main';



const Home = () => <Async load={import('./Home')} />;

const App = ({ user }) => (
  <div className={user.token ? 'container-fluid' : 'login-page'}>
    <div className={user.token ? 'row' : 'login-page-main'}>
      <Header />
      <Switch>
        {user.token && <Route path="/" component={Home} />}
        <Route path="/login" component={Login} />
        <Redirect to="/login" />
      </Switch>
    </div>
  </div>
);

App.propTypes = {
  user: PropTypes.shape({}).isRequired,
};

export default withRouter(connect(state => ({ user: state.user}))(App));
