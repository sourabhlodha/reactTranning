import React from 'react';
import PropTypes from 'prop-types';


const Form = ({ onSubmit }) => (
  <form onSubmit={onSubmit}>
    <div className="form-group">
      <input
        type="email"
        name="email"
        placeholder="Email address"
        title="Enter your email address"
        className="form-control"
        required
      />
    </div>
    <div className="form-group">
      <input
        type="password"
        name="password"
        placeholder="Password"
        title="Type a strong password"
        className="form-control"
        required
      />
    </div>
    <input className="btn btn-primary btn-block" type="submit" value="Continue" />
  </form>
);

Form.propTypes = {
  onSubmit: PropTypes.func.isRequired,
};

export default Form;
