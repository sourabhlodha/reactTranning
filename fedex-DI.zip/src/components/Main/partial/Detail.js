import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';

const Detail = ({ ...props }) => {

  // console.log(props);
  return (
   
      <div className="main-table">
        <div className="container">
          <div className="table-header">
            <div className="table-meta d-flex justify-content-between">
              <div className="total-count">
                <strong>Current Shipment </strong>
              </div>
            </div>
            <table className="table">
              <thead>
                <tr>
                  <th>Name</th>
                  <th>Details</th>
                 
                </tr>
                
              </thead>
            </table>
          </div>
          <div className="table-main-body">
            <table className="table">
              <tbody>
                <tr>
                 <td>Shipment ID</td>
               <td>{props.newData.additionalinfo.shipmentId}</td>
                  </tr>
                  <tr>
                  <td>Package Content</td>
                   <td>{props.newData.packageshipment.packagecontent}</td>
                  </tr>
                   <tr>
                  <td>Package Quantity</td>
                   <td>{props.newData.packageshipment.quantity}</td>
                  </tr>
                  <tr>
                  <td>From City</td>
                   <td>{props.newData.from.city}</td>
                 
                  </tr>
                  <tr>
                  <td> From Country</td>
                  <td>{props.newData.from.country}</td> 
                  </tr>
                  <tr>
                  <td>From Postal Code</td>
                  <td>{props.newData.from.postal}</td>
                  <tr>
                  <td>To</td>
                  <td>{props.newData.to.city}</td>
                  </tr>
                  <tr>
                  <td>To Country</td>
                  <td>{props.newData.to.country}</td>
                  </tr>
                  <tr>
                  <td>To Postal</td>
                  <td>{props.newData.to.postal}</td>
                  </tr>
                  <tr>
                  <td>Shipment Date</td>
                   <td>{props.newData.additionalinfo.shipdate}</td>
                  </tr>
                  </tr>
              </tbody>
            </table>
            <input type="button" onClick={props.submit} value="Submit"/>
             <input type="button" onClick={props.back} value="Back"/>

          </div>
        </div>
      </div>
    
  );
};

Detail.propTypes = {
  newData: PropTypes.object,
  submit:PropTypes.func,
  back:PropTypes.func,
};

export default Detail;