import React, { Component } from 'react';
import PropTypes from 'prop-types';

import MeterNeedlg from '../../../assets/images/svg-meter-gauge-needle.svg';

class Gauge extends Component {
  constructor(props) {
    super(props);
    this.state = {
      value: 50,
    };
  }
  
  componentDidMount() {
    if (this.props.caged.caged) {
      const cagedValue = this.props.caged.caged * 10;
      this.setState({ value: cagedValue });
    }
  }


  render() {
    // const deg = 270;
    const percent = this.state.value;
    const deg = 270 + ((percent * 180) / 100);
    const rotate = 'rotate('+deg+'deg)';

    const r = 150;
    const cf = 2 * Math.PI * r;
    const semi_cf = cf / 2;
    
    const meterValue = semi_cf - ((percent * semi_cf) / 100);
    // mask.setAttribute('stroke-dasharray', meter_value + ',' + cf);
    
    const needleStyle = {
      transform: rotate,
    };
    return (
      <div id="wrapper" className="meter-gauge">
        <svg id="meter">
          <circle id="outline_curves" className="circle outline" cx="50%" cy="50%" r={r}strokeDasharray="471.23889803846896,942.4777960769379">
          </circle>
          <circle id="low" className="circle range" cx="50%" cy="50%" stroke="#19bf2b" r={r} strokeDasharray="471.23889803846896,942.4777960769379">
          </circle>
          <circle id="avg" className="circle range" cx="50%" cy="50%" stroke="#feff03" r={r} strokeDasharray="314.1592653589793,942.4777960769379">
          </circle>
          <circle id="high" className="circle range" cx="50%" cy="50%" stroke="#f30606" r={r} strokeDasharray="157.07963267948966,942.4777960769379">
          </circle>
          <circle id="mask" className="circle" cx="50%" cy="50%" r={r} strokeDasharray={`${meterValue},942.4777960769379`}>
          </circle>
          <circle id="outline_ends" className="circle outline" cx="50%" cy="50%" r={r} strokeDasharray="2,469.23889803846896">
          </circle>
        </svg>
        <img id="meter_needle" src={MeterNeedlg} alt="" style={needleStyle} />
        <div className="percentvalue">
          {percent}%
        </div>
      </div>
    );
  }
}



Gauge.propTypes = {
  caged: PropTypes.object,
};

export default Gauge;