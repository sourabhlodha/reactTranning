import React from 'react';
import PropTypes from 'prop-types';

const PackageDetail = ({...props}) => (
  <form className="pt-3">
    <div className="form-row">
      <div className="form-group col-md-6">
        <div>
          <label htmlFor="packageContents">Package contents</label>
          <div>
            <div className="form-check form-check-inline">
              <label className="form-check-label">
                <input className="form-check-input" defaultChecked={true} type="radio" name="packageContents" id="documents" value="Documents" /> Documents
              </label>
            </div> 
            <div className="form-check form-check-inline">
              <label className="form-check-label">
                <input className="form-check-input" type="radio" name="packageContents" id="products" value="Products" /> Products/Commodities
              </label>
            </div>
          </div>
        </div>
      </div>
      <div className="form-group col-md-6">
        <label htmlFor="customValue">Total customs value</label>
        <div className="d-flex">
          <input type="text" className="form-control" id="customValue" placeholder="Total customs value"/>
          <select className="form-control ml-2" id="customValuesSelect">
            <option value="ANG">Antilles Guilder</option>
            <option value="ARN">Argentinian Pesos</option>
            <option value="AWG">Arubin Florin</option>
            <option value="AUD">Australian Dollars</option>
            <option value="BSD">Bahamian Dollars</option>
            <option value="BHD">Bahraini Dinar</option>
            <option value="BBD">Barbados Dollars</option>
            <option value="BMD">Bermudian Dollars</option>
            <option value="BRL">Brazilian Real</option>
            <option value="BND">Brunei Dollars</option>
            <option value="CAD">Canadian Dollars</option>
            <option value="CID">Cayman Dollars</option>
            <option value="CHP">Chilean Pesos</option>
            <option value="CNY">Chinese Renminbi</option>
            <option value="COP">Colombian Pesos</option>
            <option value="CRC">Costa Rican Colones</option>
            <option value="CZK">Czech Koruna</option>
            <option value="DKK">Danish Krone</option>
            <option value="RDD">Dominican R. Pesos</option>
            <option value="ECD">East Caribbean Dollars</option>
            <option value="EGP">Egyptian Pound</option>
            <option value="EUR">Euro</option>
            <option value="HKD">Hong Kong Dollars</option>
            <option value="HUF">Hungarian Forint</option>
            <option value="INR">Indian Rupees</option>
            <option value="JAD">Jamaican Dollars</option>
            <option value="JYE">Japanese Yen</option>
            <option value="KUD">Kuwaiti Dinar</option>
            <option value="MOP">Macau Pataca</option>
            <option value="MYR">Malaysian Ringgit</option>
            <option value="MXN">New Mexican Pesos</option>
            <option value="NZD">New Zealand Dollars</option>
            <option value="NOK">Norwegian Krone</option>
            <option value="PKR">Pakistan Rupee</option>
            <option value="PHP">Phillipine Pesos</option>
            <option value="PLN">Polish Zloty</option>
            <option value="GTQ">Quetzales</option>
            <option value="WST">Samoa Currency</option>
            <option value="SAR">Saudi Arabian Riyal</option>
            <option value="SID">Singapore Dollars</option>
            <option value="SBD">Solomon Islands Dollars</option>
            <option value="WON">South-Korean Won</option>
            <option value="SEK">Swedish Krona</option>
            <option value="SFR">Swiss Francs</option>
            <option value="NTD">Taiwan Dollars</option>
            <option value="THB">Thai Baht</option>
            <option value="TTD">Trinidad/Tobago Dollars</option>
            <option value="TRY">Turkey Lire</option>
            <option value="DHS">UAE Dirham</option>
            <option value="USD">US Dollars</option>
            <option value="UKL">United Kingdom Pounds</option>
            <option value="VEF">Venezuelan Bolivars Fuertes</option>
          </select>
        </div>
      </div>
    </div>
    <div className="form-row">
      <div className="form-group col-lg-12">
        <div className="d-flex">
        <label htmlFor="customValue" class=" form-group col-lg-2 margin-change">HS CODE Detail</label>
          <select className="form-control ml-2" id="customValuesSelect">
            <option value="" selected="selected"></option>
            <option value="85177090">85177090 - SMART PHONE/PDA 5.46 FHD CLASS BASIC MODEL (DISPLAY)</option>
            <option value="8507600020">8507600020-OTH STRGE BATERY, LITHIUM I</option>
            
            <option value="8507208090">8507208090-OTHER LEAD-ACID STOR BATT</option>
            
          </select>
        </div>
        </div>
      </div>
    

    <div className="form-header pt-3 pb-1 mb-3">
      <h2>Enter individual package information:</h2>
    </div>
    <div className="package-information">
      <table className="table table-bordered">
        <thead className="thead-dark">
          <tr>
            <th width="5%">&nbsp;</th>
            <th width="15%">Quantity</th>
            <th width="20%">Weight<br/><small>(per package)</small></th>
            <th width="20%">Package type</th>
            <th width="40%">Declared value<br/><small>(per package)</small></th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              <label className="form-check-label">
                <input type="checkbox" className="form-check-input" />
              </label>
            </td>
            <td>
              <input type="text" className="form-control" id="quantity_1" />
            </td>
            <td>
              <div className="d-flex">
                <input type="text" className="form-control" id="weight_1"/>
                <select className="form-control ml-1" id="weight_type_1">
                  <option value="lbs">lbs</option>
                  <option value="kgs">kgs</option>
                </select>
              </div>
            </td>
            <td>
              <select className="form-control" id="package_type_1">
                <option value="0">Select</option><option value="6">FedEx Envelope</option><option value="2">FedEx Pak</option><option value="3">FedEx Box</option><option value="4">FedEx Tube</option><option value="5">FedEx 10kg Box</option><option value="25">FedEx 25kg Box</option><option value="1">Your Packaging</option>
              </select>
            </td>
            <td>
              <div className="d-flex">
                <input type="text" className="form-control" id="value_1"/>
                <select className="form-control ml-1" id="value_type_1">
                  <option value="ANG">Antilles Guilder</option>
                  <option value="ARN">Argentinian Pesos</option>
                  <option value="AWG">Arubin Florin</option>
                  <option value="AUD">Australian Dollars</option>
                  <option value="BSD">Bahamian Dollars</option>
                  <option value="BHD">Bahraini Dinar</option>
                  <option value="BBD">Barbados Dollars</option>
                  <option value="BMD">Bermudian Dollars</option>
                  <option value="BRL">Brazilian Real</option>
                  <option value="BND">Brunei Dollars</option>
                  <option value="CAD">Canadian Dollars</option>
                  <option value="CID">Cayman Dollars</option>
                  <option value="CHP">Chilean Pesos</option>
                  <option value="CNY">Chinese Renminbi</option>
                  <option value="COP">Colombian Pesos</option>
                  <option value="CRC">Costa Rican Colones</option>
                  <option value="CZK">Czech Koruna</option>
                  <option value="DKK">Danish Krone</option>
                  <option value="RDD">Dominican R. Pesos</option>
                  <option value="ECD">East Caribbean Dollars</option>
                  <option value="EGP">Egyptian Pound</option>
                  <option value="EUR">Euro</option>
                  <option value="HKD">Hong Kong Dollars</option>
                  <option value="HUF">Hungarian Forint</option>
                  <option value="INR">Indian Rupees</option>
                  <option value="JAD">Jamaican Dollars</option>
                  <option value="JYE">Japanese Yen</option>
                  <option value="KUD">Kuwaiti Dinar</option>
                  <option value="MOP">Macau Pataca</option>
                  <option value="MYR">Malaysian Ringgit</option>
                  <option value="MXN">New Mexican Pesos</option>
                  <option value="NZD">New Zealand Dollars</option>
                  <option value="NOK">Norwegian Krone</option>
                  <option value="PKR">Pakistan Rupee</option>
                  <option value="PHP">Phillipine Pesos</option>
                  <option value="PLN">Polish Zloty</option>
                  <option value="GTQ">Quetzales</option>
                  <option value="WST">Samoa Currency</option>
                  <option value="SAR">Saudi Arabian Riyal</option>
                  <option value="SID">Singapore Dollars</option>
                  <option value="SBD">Solomon Islands Dollars</option>
                  <option value="WON">South-Korean Won</option>
                  <option value="SEK">Swedish Krona</option>
                  <option value="SFR">Swiss Francs</option>
                  <option value="NTD">Taiwan Dollars</option>
                  <option value="THB">Thai Baht</option>
                  <option value="TTD">Trinidad/Tobago Dollars</option>
                  <option value="TRY">Turkey Lire</option>
                  <option value="DHS">UAE Dirham</option>
                  <option value="USD">US Dollars</option>
                  <option value="UKL">United Kingdom Pounds</option>
                  <option value="VEF">Venezuelan Bolivars Fuertes</option>
                </select>
              </div>
            </td>
          </tr>
        </tbody>
        <tfoot>
          <tr>
            <td>&nbsp;</td>
            <td>1</td>
            <td>1.00 kgs</td>
            <td>&nbsp;</td>
            <td>0.00 US Dollars</td>
          </tr>
        </tfoot>
      </table>
      <div className="table-new-row-btns  d-flex justify-content-end ">
        <button type="button"  className="btn btn-outline-primary">Delete Row</button>
        <button type="button"  className="btn btn-primary ml-2">Add Row</button>
      </div>
    </div>
    <div className="pt-4">
      <div className="card">
        <div className="card-header">
          <button type="button"  className="btn btn-secondary">Add special services</button>
        </div>
        <div className="card-body">
          <h4 className="card-title">FedEx measurement tools</h4>
          <a href="#">Measurement Converter</a>
          <a href="#" className="ml-2">Currency Converter</a>
        </div>
      </div>
    </div>
    <div className="form-buttons d-flex justify-content-end py-4 mb-5">
      <button type="button" className="btn btn-primary" onClick={props.nextPage}>Continue</button>
    </div>
  </form>
    
);

PackageDetail.propTypes = {
  nextPage: PropTypes.function,
};

export default PackageDetail;