import React from 'react';
import PropTypes from 'prop-types';

const Rates = ({ ...props }) => (
  <form>
    <div className="form-header pt-5 pb-1 mb-4 justify-content-end d-flex">
      Amounts are shown in USD
    </div>
    <div className="package-information">
      <table className="table table-bordered">
        <thead className="thead-dark">
          <tr>
            <th width="20%">Select</th>
            <th width="30%">Delivery Date/Time</th>
            <th width="30%">Service</th>
            <th width="20%">Rates</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td>
              <label className="form-check-label">
                <input type="checkbox" className="form-check-input" checked />
              </label>
            </td>
            <td>
              Wed Nov 9, 2017 
            </td>
            <td>
              FedEx International Priority®
            </td>
            <td>
             76.73
            </td>
          </tr>
        </tbody>
      </table>
    </div>
    <div className="pt-4">
      <div className="card mb-4">
        <h4 className="card-header">Estimated Duties and Taxes</h4>
        <div className="card-body">
          <p>
            Certain countries have duty and tax exemptions that may apply based on the declared customs value. Your duty and tax estimate does not take these exemptions into consideration. Learn more.
          </p>
        </div>
      </div>
      <div className="card mb-4">
        <h4 className="card-header">More information about your results:</h4>
        <div className="card-body">
          <p>
            Important for Customs: To prevent delays, your shipment must have the following customs documents attached: Commercial Invoice, Certificate of Origin, Shippers Export Declaration. Additional clearance documents may also be required. For more information, please visit our international tools site.
          </p>
          <p>
            For countries where zip/postal code or city name can be entered, it is recommended that zip/postal code be entered to obtain a more accurate number of available services.
          </p>
        </div>
      </div>
      <div className="card">
        <h4 className="card-header">FedEx measurement tools</h4>
        <div className="card-body">
          <a href="#">Currency Converter</a>
        </div>
      </div>
    </div>
    <div className="form-buttons d-flex justify-content-end py-4 mb-5">
      <button type="button"  className="btn btn-outline-primary">Rate another package</button>
      <button type="button"  className="btn btn-outline-primary ml-2">View/Print rate details</button>
      <button type="button"  className="btn btn-outline-primary ml-2">Schedule a pickup</button>
      <button type="button"  className="btn btn-primary ml-2" onClick={props.ship}>Ship</button>
    </div>
  </form>
);


Rates.propTypes = {
  ship: PropTypes.function,
};

export default Rates;