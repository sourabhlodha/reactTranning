import React from 'react';
import PropTypes from 'prop-types';

import Packages from '../../../assets/images/fed-ex.png';
import Caege from '../../../assets/images/caege.jpg';
import Delayed from '../../../assets/images/delayed.jpg';

const LandingPageTop = ({ ...props }) => (
  <div className="body-top">
    <div className="body-couts">
      <div className="container">
        <div className="row align-items-center col-height text-center">
          <div className="col-sm-4">
            <div className="package-meta">
              <div className="item-images">
                <img src={Packages} />
              </div>
              <div className="item-detail">
                <div className="item-name">
                  Total Shipments
                </div>
                <div className="item-numeber">
                  {props.totalPackage}
                </div>
              </div>
            </div>
          </div>
          <div className="col-sm-4">
            <div className="package-meta">
              <div className="item-images">
                <img src={Caege} />
              </div>
              <div className="item-detail">
                <div className="item-name">
                  Probability of Caging 
                </div>
                <div className="item-numeber">
                  {props.totalCaging}
                </div>
              </div>
            </div>
          </div>
           <div className="col-sm-4">
            <div className="package-meta">
              <div className="item-images">
                <img src={Delayed} />
              </div>
              <div className="item-detail">
                <div className="item-name">
                  Caged Shipments 
                </div>
                <div className="item-numeber">
                  {props.totalCagedSipments}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
);

LandingPageTop.propTypes = {
  totalPackage: PropTypes.number,
  totalCaging: PropTypes.number,
};

export default LandingPageTop;