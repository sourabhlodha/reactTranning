import React from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';
import search from '../../../assets/images/search.png';
import hbase from '../../../assets/images/hbase.png';

const DashboardPage = ({ ...props }) => {
  const table=_.map(props.newTableData, (item, i) => {
    return (
      <div className="table-main mb-5" key={i}>
          <div className="total-count mb-2">
            Key: <span className="badge badge-pill badge-primary">{item.awbnbr}</span>
          </div>
          <div className="table-items">
            <table className="table table-bordered table-responsive">
              <thead className="table-header">
                <tr>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>totalpieceqty</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>caged</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>origincountry</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>DestinationCountry</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>DestinationAddress</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>shipdate</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>totalwgt</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>currency</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>valus</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>taxex</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>nfbrk</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>impnr</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>origin_country_lat</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>origin_country_lon</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>packagingtypecd</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>no</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>crnec</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>desci</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>fda</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>hold</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>impno</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>customsvalueamt</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>ecicd</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>ytest</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>others</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>meterflg</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>danggoodscd</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>serivcebasecd</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>sample</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>gift</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>empty</span></th>
                  <th><span className="badge badge-pill badge-primary">fcf</span><span>battery</span></th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>{item.totalpieceqty}</td>
                  <td>{item.caged}</td>
                  <td>{item.origincountry}</td>
                  <td>{item.destcountry}</td>
                  <td>{item.destaddresss}</td>
                  <td>{item.shipdate}</td>
                  <td>{item.totalwgt}</td>
                  <td>{item.currency}</td>
                  <td>{item.valus}</td>
                  <td>{item.taxex}</td>
                  <td>{item.nfbrk}</td>
                  <td>{item.impnr}</td>
                  <td>{item.origin_country_lat}</td>
                  <td>{item.origin_country_lon}</td>
                  <td>{item.packagingtypecd}</td>
                  <td>{item.no}</td>
                  <td>{item.crnec}</td>
                  <td>{item.desci}</td>
                  <td>{item.fda}</td>
                  <td>{item.hold}</td>
                  <td>{item.impno}</td>
                  <td>{item.customsvalueamt}</td>
                  <td>{item.ecicd}</td>
                  <td>{item.ytest}</td>
                  <td>{item.otders}</td>
                  <td>{item.meterflg}</td>
                  <td>{item.danggoodscd}</td>
                  <td>{item.serivcebasecd}</td>
                  <td>{item.sample}</td>
                  <td>{item.gift}</td>
                  <td>{item.empty}</td>
                  <td>{item.battery}</td>
                </tr>
              </tbody>
            </table>
          </div>
        
        </div>    
    );
  });

  return (
    <div className="main-page-container">
     
       <nav className="navbar navbar-toggleable-md navbar-light bg-faded navbar-color">
         
            <a className="navbar-brand" href="#"><img src={hbase}/></a>
      </nav>

      <div className="form-search">
        
        <form onSubmit={props.onSearch}>
          <div className="input-group">
            <input type="text" className="form-control" value={props.searchValue} onChange={props.onSearchChange} placeholder="Search for..." aria-label="Search for..." />
            <span className="input-group-btn">
              <button onClick={() => {}} className="btn btn-light p-0" type="submit"><img src={search} width="38"/></button>
            </span>
          </div>
        </form>
      </div>
      {table}
      <nav aria-label="Page navigation example">
        <ul className="pagination justify-content-center">
          <li className="page-item disabled">
            <a className="page-link" href="#" >Previous</a>
          </li>
          <li className="page-item"><a className="page-link" onClick={props.refresh}>1</a></li>
          <li className="page-item"><a className="page-link" onClick={props.previous}>2</a></li>
          <li className="page-item"><a className="page-link" onClick={props.refresh}>3</a></li>
          <li className="page-item"><a className="page-link" onClick={props.previous}>...</a></li>
          <li className="page-item">
            <a className="page-link" href="#">Next</a>
          </li>
        </ul>
      </nav>
    </div>
  );
};

DashboardPage.propTypes = {
  newTableData: PropTypes.array,
  refresh: PropTypes.func,
  previous: PropTypes.func,
  searchValue: PropTypes.string,
  onSearchChange: PropTypes.func,
  onSearch: PropTypes.func,
};

export default DashboardPage;