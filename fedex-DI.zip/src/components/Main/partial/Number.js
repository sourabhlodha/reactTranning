import React from 'react';
import PropTypes from 'prop-types';

import Gauge from './Gauge';
// import ChartTwo from './ChartTwo';

const Number = ({ ...props }) => {
  // console.log(props);
  // const className = 'badge badge-pill badge-light';
  const data = props.newData;
  let additionalInfo;

  if (data.caged > 6) {
    additionalInfo = (
      <div className="card border-success">
        <div className="card-header border-success d-flex justify-content-between">
          <h5>Additional Parameters</h5>
        </div>
        <div className="card-body text-large">
          <ul>
          
          <li>
            Incomplete documentation 
          </li>
            <li>
              Country of manufacture
            </li>
            <li>
              Dest. Address Validation
            </li>
            <li>
              Product Description
            </li>
          </ul>
       </div>
      </div>

    );
  }
  return (   
    <div className="main-body-container p-0">
      <div className="p-3 bg-primary  d-flex justify-content-between headertops">
        <button className="btn btn-link" onClick={props.backDetail} >Back</button>
        <div className="btn btn-link">Shipment id: <span>{data.shippmentid}</span></div>
      </div>
      <div className="p-4">
        <div className="card-group">
        
        
          <div className="card border-success" >
            <div className="card-header border-success">
            
              <h5>Shipment Caging Probability</h5>
            
            </div>
            <div className="card-body">
              <Gauge caged={props.newData} />
            </div>
            <div className="card-footer badges-card">
              <span className={data.caged > 6 && data.accessories > 0 ? 'badge badge-pill badge-danger': 'badge badge-pill badge-light'}>Accessories</span>
              <span className={data.caged > 6 && data.chemical > 0 ? 'badge badge-pill badge-danger': 'badge badge-pill badge-light'}>Chemical</span>
              <span className={data.caged > 6 && data.circuit > 0 ? 'badge badge-pill badge-danger': 'badge badge-pill badge-light'}>Circuit</span>
              <span className={data.caged > 6 && data.medical > 0 ? 'badge badge-pill badge-danger': 'badge badge-pill badge-light'}>Medical</span>
              <span className={data.caged > 6 && data.part > 0 ? 'badge badge-pill badge-danger': 'badge badge-pill badge-light'}>Part</span>
              <span className={data.caged > 6 && data.sample > 0 ? 'badge badge-pill badge-danger': 'badge badge-pill badge-light'}>Sample</span>
              <span className={data.caged > 6 && data.surgical > 0 ? 'badge badge-pill badge-danger': 'badge badge-pill badge-light'}>Surgical</span>
              <span className={data.caged > 6 && data.inflammable > 0 ? 'badge badge-pill badge-danger': 'badge badge-pill badge-light'}>Inflammable</span>
            </div>
          
          </div>
          {additionalInfo}
        </div>
      </div>
    </div>
  );
};

Number.propTypes = {
  newData: PropTypes.object,
  backDetail:PropTypes.func,
};

export default Number;