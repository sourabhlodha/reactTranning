import React from 'react';
import PropTypes from 'prop-types';
import ShippingInformation from './forms/ShippingInformation';
import PackageDetails from './forms/PackageDetails';
import Rates from './forms/Rates';
import Notes from './Notes';

const MainPageDetail = ({ ...props }) => {
  let tabContent;
  if(props.page === 'packageDetails') {
    tabContent = <PackageDetails nextPage={props.nextPage} />;
  }
  
  if (props.page === 'shippingInformation') {
    tabContent = <ShippingInformation ship={props.ship} nextPage={props.nextPage} autofill={props.autofill}  />;  
  }
  if (props.page === 'rates') {
    tabContent = <Rates ship={props.ship}/>;
  }

  return (
    <div className="main-body-container">
      <div className="top-tab-navigation d-flex flex-row">
        <div className="tab-item col p-0">
          <button onClick={props.goToPage1}  type="button" className={`tab-button btn-block btn btn-link ${props.page === 'shippingInformation' ? 'active' : 'hello'}`}>Shipping Information</button>
        </div>
        <div className="tab-item col p-0">
          <button type="button" onClick={props.goToPage2} className={`tab-button btn-block btn btn-link ${props.page === 'packageDetails' ? 'active' : 'hello'}`}>Package and Shipment Details</button>
        </div>
        <div className="tab-item col p-0">
          <button onClick={props.goToPage3}  type="button" className={`tab-button btn-block btn btn-link ${props.page === 'rates' ? 'active' : 'hello'}`}>Rates and Transit Times</button>
        </div>
      </div>
      <div className="tab-container">
        {tabContent}
      </div>
      <Notes />
    </div>
  );
};

MainPageDetail.propTypes = {
  page: PropTypes.string,
  nextPage: PropTypes.func,
  goToPage1: PropTypes.func,
  goToPage2: PropTypes.func,
  goToPage3: PropTypes.func,
  autofill: PropTypes.func,
  ship: PropTypes.func,
};

export default MainPageDetail;

