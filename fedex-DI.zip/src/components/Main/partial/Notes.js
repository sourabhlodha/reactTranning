import React from 'react';
const Notes = () => (
  <div className="aditionalInformation">
    <h3>Please note:</h3>
    <ul>
      <li>
        Rates shown here may be different than the actual charges for your shipment. Differences may occur based on actual weight, dimensions, currency conversion rate and other factors. Consult the applicable FedEx Service Guide for details.
      </li>
      <li>
        Looking for a better rate for your large, last-minute, international shipment? Please visit the <a href="/greatrates/info.html">FedEx Great Rates Hotline</a>.
      </li>
      <li>
        FedEx Multiweight pricing is available for multiple-piece shipments to one destination on the same day totaling 100 lbs or more for Express and 200 lbs or more for Ground Multiweight pricing available via a contract only.
      </li>
      <li>
        Please do not use <a href="/us/service-guide/our-services/package-shipment/index.html">FedEx Express packaging</a> for your FedEx Ground or FedEx Home Delivery shipments.
      </li>
      <li>Please refer to your pricing agreement for the surcharge specific to your account number.</li>
      <li>The rate and transit time application only uses city name or zip/postal code to define transit time.</li>
      <li>Certain commodities and high value shipments may require additional transit time for clearance.</li>
      <li>The rate and transit time application bases its transit time on zip/postal code over city when both are provided.</li>
      <li>"End of day" means the end of the FedEx business day for deliveries in the destination's time zone. The exact time may vary by destination.</li>
      <li>If you selected that your shipment contains a Letter, the transit time results that appear above are based on a letter shipment containing a personal or business letter with no commercial value. Annual reports, Brochures, and Newspapers are among a variety of documents deemed by some governments to have a commercial value. They are considered to be products rather than documents or letters by customs, and may require additional import/export clearance. If you believe that your document may be considered to have a commercial value, please request a new transit time quote and search for your document type among the product categories.</li>
      <li>The product or document category that you select is only used to determine the transit time for your shipment. For import/export clearance, please define your product in detail on the Air Waybill and Customs documentation that accompany your shipment.</li>
      <li>The transit time results shown are based on the shipment date you provided. The results are valid only if your shipment is prepared and provided to FedEx by the latest published cut-off time in your origin city on the shipment date indicated and all the information entered in the rate and transit time application matches the actual shipment tendered.</li>
      <li>The service options and delivery time shown assume there are no clearance delays and are dependent on the ship date, weight, dimensions, declared value, goods descriptions, packaging, and/or address entered for your shipment. Any disparities between entered and actual data for your shipment may affect the availability of different service options and may result in a different delivery time and date. Please make sure that your shipment meets the terms and conditions of the service you have requested. For more information on FedEx terms and conditions including Money-Back Guarantee Policy, please see the <a href="/us/service-guide/our-services/index.html">FedEx Service Guide</a>.</li>
      <li>If you need a transit time for a service with special handling options, please contact <a href="/us/customersupport/">Customer Service</a>.</li>
      <li>Delivery dates and times are provided for single-commodity shipments only. Transit time information for multiple commodities is not supported in this application at this time. Please contact <a href="/us/customersupport/">Customer Service</a>.</li>
      <li>The fedex.com transit time information is subject to change without notice. Consult the <a href="/us/service-guide/our-services/index.html">FedEx Service Guide</a> for terms of shipping. In the event of a conflict between the FedEx Service Guide and the transit time on fedex.com, the terms and conditions in the FedEx Service Guide will prevail.</li>
      <li>8:00 AM or 8:30 AM service may be available for some destination zip/postal codes in the USA from anywhere in the world, and in Europe from USA, Canada or Puerto Rico. You may enter a destination zip/postal code on the From/To page to see if FedEx International First is available from your zip/postal code.</li>
      <li>If your shipment contains a dangerous good, you are must comply with air regulations for FedEx Express shipments regardless of routing or mode, and a trained shipper must identify, classify, mark, label, package, and complete the necessary documentation. If you require assistance, please call 1•800•Go•FedEx, (800) 463-3339 and press "81" to speak with a Dangerous Goods Specialist. For more information refer to the <a href="/us/service-guide/our-services/index.html">FedEx Service Guide</a>.</li>
    </ul>
  </div>
);

export default Notes;