import React, { Component } from 'react';
import PropTypes from 'prop-types';
import _ from 'lodash';

// import Time from '../../../assets/images/time.png';
// import Weather from '../../../assets/images/weather.png';
// import Traffic from '../../../assets/images/traffic.png';
// import UsaLogo from '../../../assets/images/usa.png';
// import UkLogo from '../../../assets/images/uk.png';
import search from '../../../assets/images/search.png';

import LandingPageTop from './LandingPageTop';

class LandingPage extends Component {
  constructor(props) {
    super(props);
    this._interVal = this._interVal.bind(this);
    this._interCaging = this._interCaging.bind(this);
    this._clearInterval = this._clearInterval.bind(this);
    this._onSearch = this._onSearch.bind(this);

    this._handleOnChange = this._handleOnChange.bind(this);
    this._interCaginged = this._interCaginged.bind(this);
    this._numberWithCommas = this._numberWithCommas.bind(this);

    this.state = {
      count: props.count,
      newDataCount: props.newDataCount,
      newData: props.newData,
      data: props.data,
      shippingID: '',
      newRowData: '',
      newRowDataItem: '',
      totalPackage: 456246,
      totalCaging: 5472,
      totalCagedSipments: 1472, 
    };
  }

  _numberWithCommas(x) {
    return x.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  }
  
  componentDidMount() {
    this.setState({ newRowData: this.props.newData }, () => {
      this.intervalId  = setInterval(this._interVal, 500);
      this.intervalCaging  = setInterval(this._interCaging, 5000);
      this.intervalCaginged  = setInterval(this._interCaginged, 10000);
    });
  }

  _interVal() {
    this.setState({ count: this.state.count + 1, newDataCount: this.state.newDataCount + 1, totalPackage: this.state.totalPackage + 1 }, ()=> {
      this.state.newData.unshift(this.state.data[this.state.count]);
      if(this.state.count === this.state.data.length - 1) {
        this.setState({ count: 0});
      }
    });
  }

  _interCaging() {
    this.setState({ totalCaging: this.state.totalCaging + 1 });
  }
  _interCaginged() {
    this.setState({ totalCagedSipments: this.state.totalCagedSipments + 1 });
  }

  _clearInterval() {
    clearInterval(this.intervalId);
  }

  _onSearch() {
    this._clearInterval();
    const newRowData = [];
    _.map(this.state.data, item => {
      if(item.shippmentid === this.state.shippingID) {
        newRowData.push(item);
      }
    });
    this.setState({ newRowDataItem: newRowData[0], newRowData: '' });
  }

  _handleOnChange(e) {
    this.setState({ shippingID: Number(e.target.value) });
  }

  componentWillUnmount() {
    this._clearInterval();
  }

  componentWillReceiveProps(nextProps) {
    if(nextProps.newData) {
      this.setState({ newRowData: nextProps.newData });
    }
  }

  render () {
    const props = this.props;
    const totalCagedSipments = this._numberWithCommas(this.state.totalCagedSipments);
    const totalCaging = this._numberWithCommas(this.state.totalCaging);
    const totalPackage = this._numberWithCommas(this.state.totalPackage); 
    // console.log(this.state.newRowData);
    const items = [];
    items.push(this.state.newRowDataItem);
    // console.log(items);
    const newRowDataItem = this.state.newRowData || items;
    const rowData = _.map(newRowDataItem, (item, i) => {
      // let delayFects;
      // if (item.delayFacts === 0) {
      //   delayFects = <div><img src={Time} width="20" /> On Time</div>;
      // } else if (item.delayFacts === 1) {
      //   delayFects = <div><img src={Weather} width="20"/> Bed Weather</div>;
      // } else {
      //   delayFects = <div><img src={Traffic} width="20"/> Traffic Jam </div>;
      // }
      // let colorClass = 'color-2';
      // if (item.caged > 0.7) {
      //   colorClass = 'color-1';
      // }
      let occ;
      let dcc;
      let originUrl;
      let destUrl; 
      if(item) {
        occ = _.toLower(item.origincountry);
        dcc = _.toLower(item.destcountry);
        originUrl = require('../../../assets/images/'+occ+'.png');
        destUrl = require('../../../assets/images/'+dcc+'.png');
      }

      // let originUrl = `../../../assets/images/${_.toLower(item.origincountry)}.png`;
      // let destUrl = `../../../assets/images/${_.toLower(item.destcountry)}.png`;

      return (
        <tr key={i}  onClick={() => props.onClick(item)}>
          <td width="18%">{item.shippmentid}</td>
          <td width="18%">
            <div><img src={originUrl} width="20"/> {item.origincountry} </div>
          </td>
          <td width="18%">
            <div><img src={destUrl} width="20" /> {item.destcountry} </div>
          </td>
          <td width="16%">{item.HSCode}</td>
          <td width="20%"><div className="commodity">{item.CommodityDesc}</div></td>
          <td width="10%">{item.attchment}</td>
        </tr>
      );
    }); 
    return (
    <div className="main-body-container">
      <LandingPageTop totalPackage={totalPackage} totalCaging={totalCaging} totalCagedSipments={totalCagedSipments} />
      <div className="form-search-shipment">
        <form>
          <div className="input-group">
            <input type="text" value={this.state.shippingID} onChange={this._handleOnChange}  className="form-control" placeholder="Search for..." aria-label="Search for..." />
            <span className="input-group-btn">
              <button className="btn btn-light p-0" type="button" onClick={this._onSearch}><img src={search} width="38"/></button>
            </span>
          </div>
        </form>
      </div>
      <div className="main-table">        
        <div className="table-header p-0">
          <table className="table">
            <thead>
              <tr>
                <th width="18%">Shipment ID</th>
                <th width="18%">Origin</th>
                <th width="18%">Destination</th>
                <th width="16%">HS Code</th>
                <th width="20%">Commodity Desc</th>
                <th width="10%">Attachment</th>
              </tr>
            </thead>
          </table>
        </div>
        <div className="table-main-body">
          <table className="table table-bordered table-shipment">
            <tbody>
              {rowData}
            </tbody>
          </table>
        </div>
       
      </div>
    </div>
    );
  }
}

LandingPage.propTypes = {
  newData: PropTypes.array,
  onClick: PropTypes.func,
  newDataCount: PropTypes.number,
  count: PropTypes.number,
  data: PropTypes.array,

};

export default LandingPage;